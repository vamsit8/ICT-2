<!DOCTYPE html>
<?php
 session_start();?>
<html lang="en">
<head>
	<title>THE GOLDENLOR</title>
	<?php include("include/head.inc") ?>
</head>
<body>
	<?php include("include/nav.inc") ?>
	
	<div class="container">
		<div class="row">
			<div class="col-12"><h4>Registered Succesfully</h4></div>
		</div>
		<div class="row" >
			<div class="col-12"  ><a href="clogin.php" style="text-decoration: none; color: black;"><h1>Login here </h1> </a></div>
			<div class="col-12"><a href="menu.php" style="text-decoration: none; color: black;"><h1>Go Back to menu</h1></a></div>
		</div>
	</div>

   <div style="height:260px; clear: both;">&nbsp;</div>

</body>
<?php include("include/footer.inc") ?>

</html>

