<?php
session_start();
include("include/config.php");
?>
<html>
<head>
	<?php include("include/head.inc")?>
	<?php include("include/nav.inc")?>

</head>


<body>
	 <div class="container" style="width:200px  padding:5%";>  
                <h3 align="center">Your Profile</h3><br />  
                <div class = "row">
                <?php 

                $conn  = db_connect(); 
                $user = $_SESSION["login_v"];
                $query = "SELECT * FROM users where username = '$user'";  
                $result = mysqli_query($conn, $query);  

                if(mysqli_num_rows($result) > 0)  
                {     
                     while($row = mysqli_fetch_array($result))  
                     { ?>
                     		
               <div class="col-md-6 img" style=" text-align:center ";>
               <img src="<?php if (is_null($row["profile_picture"])) { ?>images/avatar.png<?php 
					} else{  echo $row["profile_picture"]; }?>" class="col-md-6 img" style= "text-align:center height:200px"; /><br />
           </div>

                     
               	<div class="col-md-6 details" style=" font-size:15px; font-weight:bold";>
               		<div class="col-md-6 details" style=" border-left:3px solid #ded4da";>
                                <label for="fname">profile picture</label>
                                <h4 class="fileToUpload"><?php echo $row["profile_picture"]; ?></h4> 
                                <label for="name">User-Name</label>
                                <h4 class="text-info"><?php echo $row["username"]; ?></h4> 
                                <label for="name">Fname</label>
                               <h4 class="text-info"><?php echo $row["fname"]; ?></h4>
                               <label for="name">Lname</label>  
                               <h4 class="text-info"><?php echo $row["lname"]; ?></h4>
                               
                                <label for="name">Address</label>
                               <h4 class="text-info"><?php echo $row["address"]; ?></h4>
                               <label for="name">Postcode</label>
                               <h4 class="text-info"><?php echo $row["postcode"]; ?></h4>
                               <label for="name">Phone</label>
                                <h4 class="text-info"><?php echo $row["phone"]; ?></h4>
                                
                               

               </div>
           </div>
       </div>
               <?php
                     }
                }  
                ?>

               
           </div>
       </div>
</body>
<?php include("include/footer.inc")?></html>
</html>
