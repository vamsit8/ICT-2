<?php
session_start();
include_once('include/config.php');
if(isset($_POST['uname'])) {
    //make the database connection
  $_SESSION['login_v'] = $_POST['uname'];
}
?>
<html lang="en">
<head>
<?php include("include/head.inc")?>
<body onLoad="run_first()">
 <?php include("include/nav.inc")?></head>
  
  <?php
if(isset($_POST['uname'], $_POST['psw'])) {
    //make the database connection
    echo "after post";
    $conn  = db_connect();
    $Username = $conn -> real_escape_string($_POST['uname']);
    $password = $conn -> real_escape_string($_POST['psw']);
    
  $sql= "SELECT * FROM users WHERE username = '$Username' AND password = '$password' ";
  $result = $conn->query($sql);
  if ($result->num_rows > 0){
	echo "success";
	$_SESSION["login_v"] = $_POST['uname'];
	header ("location: index.php");
  }
  else 
  {
	  echo "<script>
    alert('Log in Failed');
    window.location.href='clogin.php';
  </script>";
  }
}
?>